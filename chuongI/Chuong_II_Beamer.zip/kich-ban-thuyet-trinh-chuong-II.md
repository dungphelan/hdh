# KỊCH BẢN THUYẾT TRÌNH — CHƯƠNG II: ARM CORTEX-M85

**Dùng cho:** bộ slide 22 trang trong `ch2-slides/main.tex` (bản hiện tại, 22 slide).
**Cách dùng:** Mỗi slide có 3 phần. Khi thuyết trình, bạn chỉ cần đọc phần **Nói**.
Phần **Nhớ thêm** chỉ nói khi còn thời gian, hoặc khi thầy/cô hỏi sâu — đó chính là
phần giúp bài của bạn "đủ ý" mà slide không ghi hết. Phần **Chuyển** là câu nối
sang slide sau, để bài không bị đứt.

**Thời lượng ước tính:** đọc hết phần **Nói** khoảng 12–13 phút. Nói thêm cả
phần **Nhớ thêm** thì khoảng 17–18 phút. Nếu bị nhắc hết giờ, bỏ **Nhớ thêm**,
giữ nguyên phần **Nói** và **Chuyển** thì bài vẫn đủ mạch.

---

## Slide 1 — Bìa + mục lục: Chương II. ARM Cortex-M85

**Trên slide:** Chỉ tiêu đề chương và mục lục dạng thuần (không gạch đầu dòng): 3 tiêu đề cha, các tiêu đề con lùi vào một mức, mỗi tiêu đề một dòng (1.1–1.3, 2.1–2.2, 3.1–3.6).

**Nói:**
"Thưa thầy, thưa các bạn, em trình bày Chương II của báo cáo: từ phân loại bộ xử
lý nhúng nói chung, đến vi kiến trúc của ARM Cortex-M85 nói riêng. Nhân này là
trung tâm của cả báo cáo, vì sang Chương III, nhóm sẽ dùng chính con chip
Renesas RA8M1 chạy nhân M85 để làm trạm giám sát thông minh. Chương này có ba
phần. Phần một là phân loại bộ xử lý nhúng theo bộ nhớ, tập lệnh và mức tích
hợp. Phần hai là vị trí của M85 trong hệ sinh thái Arm và trong dòng Cortex-M.
Phần ba, cũng là phần chính, là kiến trúc chuyên sâu của M85: pipeline, bộ nhớ,
Helium và bảo mật."

**Nhớ thêm:**
- Đừng mở đầu bằng định nghĩa dài. Câu hỏi dẫn dắt của cả chương là: M85 khác
  các nhân M trước ở điểm nào, mà vẫn là một vi điều khiển, không phải vi xử lý?
- Nhấn mạnh thứ tự này là có chủ ý: không thể hiểu vì sao M85 đặc biệt nếu chưa
  biết nó khác Von Neumann, RISC, MCU ở chỗ nào.
- Nếu thầy hỏi "sao lại chọn M85?", trả lời ngắn: vì nó gộp cả ba thứ vào một
  nhân M — hiệu năng scalar cao, vector Helium, và bảo mật TrustZone + PACBTI —
  mà vẫn giữ khuôn khổ MCU.

**Chuyển:** "Bắt đầu với cách phân loại đầu tiên: cấu trúc bộ nhớ."

---

## Slide 2 — Von Neumann và Harvard

**Trên slide:** Hình hai bên: Von Neumann chung bus, Harvard tách bus lệnh và dữ liệu.

**Nói:**
"Nhìn hình bên trái, kiến trúc Von Neumann dùng chung một bus và một không gian
bộ nhớ cho cả lệnh và dữ liệu. Ưu điểm là đơn giản, nhưng nhược điểm rất rõ:
khi nhân đang lấy lệnh thì không thể đồng thời đọc toán hạng, nên pipeline phải
dừng chờ. Sang hình bên phải, Harvard tách riêng bus lệnh và bus dữ liệu, nên
lấy lệnh và truy cập dữ liệu song song được."

**Nhớ thêm:**
- Harvard trả giá bằng phần cứng phức tạp hơn, và việc tự sửa mã khó hơn vì bộ
  nhớ lệnh thường là Flash hoặc ROM.
- Đừng nói Harvard "luôn nhanh hơn" — nói "song song được", vì độ trễ thực tế
  còn phụ thuộc vào bộ nhớ và pipeline.

**Chuyển:** "M85 không chọn nguyên một trong hai, mà dùng dạng cải tiến sau đây."

---

## Slide 3 — M85 dùng Modified Harvard

**Trên slide:** Các ý: bus tách riêng nhưng chung không gian địa chỉ; ITCM chứa lệnh, DTCM chứa dữ liệu.

**Nói:**
"M85 dùng Harvard cải tiến: bus lệnh và bus dữ liệu tách riêng, nhưng hai bus
nhìn chung một không gian địa chỉ thống nhất. Nhờ đó, nhân vừa giữ được băng
thông song song của Harvard, vừa đọc được dữ liệu trong bộ nhớ lệnh, ví dụ như
hằng số đặt trong Flash. Trên M85, ví dụ cụ thể của việc tách riêng này là
ITCM chứa lệnh và DTCM chứa dữ liệu."

**Nhớ thêm:**
- Hai điểm rất dễ bị hỏi vặn, phải nói rõ: thứ nhất, ITCM/DTCM là vùng cấu hình
  tùy chọn, không phải là định nghĩa của Modified Harvard. Thứ hai, độ trễ TCM
  là thấp và xác định, nhưng không phải lúc nào cũng đúng một chu kỳ — nó còn
  phụ thuộc loại truy cập và đặc tính pipeline.
- Đừng nói "TCM không có độ trễ". Nói "độ trễ thấp và xác định, không phụ thuộc
  vào trạng thái cache như bộ nhớ thường".

**Chuyển:** "Xong cấu trúc bộ nhớ, sang cách phân loại thứ hai: tập lệnh."

---

## Slide 4 — RISC và CISC

**Trên slide:** Bảng so sánh CISC/RISC, kết luận M85 dùng Thumb-2 thuộc trường phái RISC.

**Nói:**
"Nhìn bảng, CISC cho một lệnh làm nhiều việc, thậm chí thao tác trực tiếp lên
bộ nhớ, nên thời gian thực thi biến thiên lớn và khó dự đoán. RISC thì ngược
lại: lệnh đơn giản, mỗi lệnh một việc, chỉ có lệnh load và store mới được chạm
vào bộ nhớ, nên thời gian chạy đều và dễ dự đoán hơn. M85 dùng tập lệnh
Thumb-2, trộn lệnh 16-bit và 32-bit để giữ mật độ mã cao mà vẫn giải mã nhanh,
và thuộc trường phái RISC. Vì sao lại trộn? Vì lệnh 16-bit gọn, hợp với các thao
tác thường gặp nên tiết kiệm Flash, còn lệnh 32-bit dành cho thao tác phức tạp
cần nhiều toán hạng hoặc hằng số lớn — một tập lệnh duy nhất, bộ giải mã phân
biệt bằng các bit đầu của lệnh."

**Nhớ thêm:**
- Ý "RISC không tự động bảo đảm tính tất định" đã được bỏ khỏi slide này theo
  comment của bạn, vì lúc này người nghe chưa biết in-order, TCM, NVIC là gì.
  Chỉ nhắc lại ý đó ở slide 12 (pipeline in-order), khi nó đã có ngữ cảnh.
- Nếu thầy hỏi "sao không dùng CISC cho gọn mã?", trả lời: mã CISC gọn hơn
  nhưng thời gian thực thi biến thiên, không hợp với hệ thời gian thực.

**Chuyển:** "Cùng là RISC, nhưng MCU và MPU thì khác nhau ở mức tích hợp."

---

## Slide 5 — MCU và MPU (mục 1.3)

**Trên slide:** Hình trái MCU tất cả trong một chip, phải MPU nhớ và ngoại vi gắn ngoài; các ý MCU/MPU.

**Nói:**
"MCU, tức vi điều khiển, tích hợp nhân, bộ nhớ và ngoại vi trong một chip duy
nhất, chạy bare-metal hoặc RTOS, và thường không cần bộ nhớ ngoài. MPU, tức vi
xử lý, thì tập trung vào năng lực xử lý, RAM, ROM và ngoại vi gắn ngoài qua
bus, nhiều thiết kế dùng MMU nên chạy được hệ điều hành đầy đủ như Linux. Cái
giá của MPU là bus ngoài, năng lượng và chi phí cao hơn. M85 giữ khuôn khổ MCU:
không có MMU."

**Nhớ thêm:**
- Đây là slide trả lời trước câu hỏi "M85 mạnh vậy sao không gọi là MPU?".
  Đáp án nằm ở hai chữ "không MMU" và "đơn chip": M85 vẫn chạy RTOS/bare-metal,
  vẫn ưu tiên chi phí, năng lượng và tính tất định.
- Đừng nói MCU "không bao giờ" dùng nhớ ngoài — một số thiết kế MCU vẫn mở rộng
  nhớ ngoài khi cần, chỉ là không bắt buộc như MPU.

**Chuyển:** "Gom ba cách phân loại vừa rồi lại, ta có tóm tắt sau đây."

---

## Slide 6 — Tóm tắt

**Trên slide:** Ba ý: Modified Harvard, RISC + Thumb-2, MCU; câu kết "Cortex-M = Harvard cải tiến + RISC Thumb-2 + khuôn khổ MCU".

**Nói:**
"Gom ba cách phân loại vừa rồi lại, Cortex-M chọn ba thứ. Về bộ nhớ, nó dùng
Harvard cải tiến: bus lệnh và bus dữ liệu tách riêng nhưng chung một không gian
địa chỉ, nên vừa lấy lệnh song song dữ liệu, vừa đọc được dữ liệu trong bộ nhớ
lệnh. Về tập lệnh, nó theo RISC với Thumb-2: lệnh đơn giản, chỉ load/store chạm
nhớ, trộn lệnh 16-bit và 32-bit để mã gọn mà vẫn giải mã nhanh. Về mức tích hợp,
nó giữ khuôn khổ MCU: nhân, nhớ và ngoại vi trong một chip, chạy bare-metal
hoặc RTOS, không có MMU, không cần nhớ ngoài. Cortex-M bằng Harvard cải tiến
cộng RISC Thumb-2 cộng khuôn khổ MCU."

**Nhớ thêm:**
- Đây là slide chốt phần 1, đừng thêm chi tiết mới (ITCM/DTCM, pipeline, NVIC
  đã có slide riêng ở phần sau).
- Nếu thầy hỏi "ba lựa chọn này liên quan gì nhau?", trả lời: cả ba cùng phục
  vụ một mục tiêu — điều khiển thời gian thực trên một chip rẻ, tiết kiệm và
  dễ dự đoán.

**Chuyển:** "Đặt MCU vào trong họ ARM, ta có ba profile sau đây."

---

## Slide 7 — Ba profile Cortex: A, R, M

**Trên slide:** Biểu đồ của Arm, ngôi sao và nhãn M85 do nhóm bổ sung; các ý A/R/M.

**Nói:**
"ARM không bán chip mà cấp phép nhân xử lý, nên Cortex là tên một họ nhân,
không phải tên một con chip. Ba profile phục vụ ba bài toán khác nhau. Profile
A là profile ứng dụng: có MMU, thường đa nhân, chạy hệ điều hành đầy đủ. Profile
R là profile thời gian thực: dùng MPU, TCM, ECC, phục vụ ô tô và công nghiệp.
Profile M là profile vi điều khiển: tích hợp nhân, bộ nhớ và ngoại vi trong một
chip, chạy bare-metal hoặc RTOS, ưu tiên chi phí, năng lượng và tính tất định.
M85 nằm ở đỉnh họ M về hiệu năng, nhưng vẫn ở lại profile M vì không có MMU."

**Nhớ thêm:**
- Nói rõ nguồn gốc của hình: biểu đồ nền là của Arm, ngôi sao và nhãn M85 là do
  nhóm bổ sung để trực quan hóa vị trí, không phải phép đo hiệu năng.
- Thứ tự M0 → M3 → M4 → M33 → M55/M85 trên slide chỉ là định hướng theo hiệu
  năng tổng thể, không phải xếp hạng tuyệt đối, vì mỗi nhân có đánh đổi riêng.
  Nói câu này sẽ tránh bị bắt bẻ "sao M33 lại xếp sau M4".

**Chuyển:** "Vậy M85 leo lên đỉnh họ M bằng những bước nào? Nhìn vào tiến hóa của dòng M."

---

## Slide 8 — Tiến hóa dòng Cortex-M

**Trên slide:** Hình chồng tính năng theo phiên bản ISA; các tầng v6, v7, v8, v8.1.

**Nói:**
"Dòng Cortex-M đi từ Armv6-M, qua Armv7-M và Armv7E-M, rồi sang Armv8-M, và tới
Armv8.1-M. Mỗi bước không chỉ tăng xung nhịp mà cộng thêm một cơ chế mới:
v7 thêm DSP và dấu phẩy động, v8 thêm TrustZone, và v8.1 thêm Helium, PACBTI
cùng vòng lặp chi phí thấp. M85 hưởng trọn chồng tính năng này."

**Nhớ thêm:**
- Ý "mỗi bước thêm cơ chế mới, không chỉ tăng xung" là luận điểm chính của slide,
  đừng chỉ đọc danh sách phiên bản rồi chuyển slide.
- Hậu tố E trong Armv7E-M đánh dấu mở rộng DSP — nếu thầy hỏi chữ E nghĩa là gì
  thì đây là đáp án.

**Chuyển:** "Nhìn bằng mốc năng lực thì câu chuyện còn rõ hơn."

---

## Slide 9 — Mốc tiến hóa: từ tiết kiệm đến vector

**Trên slide:** Hình mốc năng lực các thế hệ Cortex-M; các ý M0+/M3, M4, M23/M33, M7, M55.

**Nói:**
"M0+ và M3 nổi tiếng siêu tiết kiệm và Thumb-2. M4 bắt đầu đưa DSP và FPU vào
MCU, tức là MCU bắt đầu xử lý tín hiệu. M23 và M33 thêm TrustZone. M7 đẩy lên
dual-issue và dấu phẩy động đơn/đôi. M55 là nhân đầu tiên có Helium, tức là
DSP và ML chuyên dụng. Và ô 'Future Cortex-M' trên hình — hình này ra đời
trước M85 — chính là chỗ M85 lấp vào: Helium nhanh hơn, ML mạnh hơn."

**Nhớ thêm:**
- Phải nói rõ hình này ra đời trước M85, nên ô "Future" không phải là tên chính
  thức của M85, mà là vị trí mà M85 lấp vào. Nói thiếu câu này rất dễ bị hiểu
  nhầm là trích dẫn sai nguồn.
- Đừng đọc hết cả 5 mốc một cách đều nhau. Nhấn vào hai bước ngoặt: M4 đưa DSP
  vào MCU, và M55/M85 đưa vector vào MCU.

**Chuyển:** "Vì sao bước vector này lại quan trọng? Vì bài toán Edge AI đã đổi."

---

## Slide 10 — Bài toán Edge AI

**Trên slide:** Hình hiệu năng truyền thống và ML; các ý ML lượng tử hóa, scalar là điểm nghẽn, đáp án Helium + Low Overhead Branch.

**Nói:**
"Mô hình học máy lượng tử hóa chạy trên MCU chủ yếu là chuỗi phép nhân và cộng
dồn trên vector dữ liệu, cộng với vòng lặp xử lý cửa sổ tín hiệu. Pipeline
scalar, dù nhanh, vẫn xử lý từng phần tử một và tốn chu kỳ cho rẽ nhánh vòng
lặp, nên khi khối lượng dữ liệu vector tăng lên, scalar trở thành điểm nghẽn.
Vì vậy, cần một mở rộng vector làm nhiều phần tử trong một lệnh, và một cơ chế
vòng lặp rẻ hơn, thay vì chỉ tăng xung nhịp. Đáp án là Helium và Low Overhead
Branch."

**Nhớ thêm:**
- Câu kết trên slide là kết luận của §2, phải đọc rõ: Edge AI cần cả hai
  trục — scalar cho bài toán truyền thống, vector cho ML. Đừng nói "vector thay
  thế scalar". Cụm "§3 đi vào Helium" đã được bỏ khỏi slide theo comment của
  bạn, nên đừng đọc thêm cụm đó khi nói — chỉ chuyển slide bình thường.
- Nếu thầy hỏi "sao không tăng xung là xong?", trả lời: tăng xung tăng năng
  lượng và vẫn tốn chu kỳ rẽ nhánh, trong khi vector xử lý nhiều phần tử trong
  một lệnh.

**Chuyển:** "Bây giờ vào phần chính: bên trong nhân M85 có gì? Bắt đầu từ sơ đồ khối."

---

## Slide 11 — Sơ đồ khối nhân Cortex-M85

**Trên slide:** Sơ đồ khối của Arm; các khối Integer Core, TCM-Control, EPU, NVIC, MAU, bus, Debug.

**Nói:**
"Nhìn sơ đồ, Integer Core nằm ở giữa, nối với TCM-Control cùng I-TCM, D-TCM và
I-Cache, D-Cache. Khối EPU lo dấu phẩy động và MVE. Xung quanh là NVIC cho ngắt,
MAU, giao diện coprocessor, các bus AXI và AHB nối nhân với hệ thống ngoài nhân
— bộ nhớ hệ thống, DMA và ngoại vi, cùng khối Debug ra JTAG và trace. Các khối
vẽ nét đứt trong hình là tùy chọn theo cấu hình, không phải chip nào cũng bật đủ."

**Nhớ thêm:**
- Câu "nét đứt là tùy chọn" phải nói, vì nó bảo vệ bạn ở mọi slide sau: nhiều con
  số của M85 là giới hạn cấu hình của IP, không phải cấu hình của mọi chip.
- Nếu thầy hỏi "bộ nhớ hệ thống" là gì, trả lời: là bộ nhớ ngoài nhân, tức là
  Flash/SRAM trong chip (nhưng ngoài nhân) và bộ nhớ ngoài chip qua giao diện.
  DMA ở đây không phải là một vùng nhớ để bus đi tới, mà là một chủ thể cũng
  dùng bus để chuyển dữ liệu.
- Ngoài sơ đồ nhân, hệ thống xung quanh còn có EWIC đánh thức từ ngủ sâu,
  EPPB, PMC-100 và CoreSight ETM/ITM/DAP — chi tiết này nằm ở slide 20, đừng
  kể hết ở đây kẻo trùng.

**Chuyển:** "Đi vào khối đầu tiên: pipeline."

---

## Slide 12 — Pipeline 7 tầng in-order

**Trên slide:** Hình pipeline IFU, DPU, LSU, EPU; các ý 7 tầng, dual-issue, triple-issue chọn lọc, FP/MVE 9–10 tầng.

**Nói:**
"M85 triển khai pipeline số nguyên 7 tầng, thực thi đúng thứ tự, tức là
in-order. Bình thường nó phát 2 lệnh mỗi chu kỳ, gọi là dual-issue. Đặc biệt,
tại tầng FD, nó có thể gập một lệnh rẽ nhánh vào cặp lệnh đang phát, tạo nên
phát 3 lệnh có chọn lọc mà thường không tốn thêm chu kỳ riêng cho lệnh nhảy.
Pipeline cho dấu phẩy động và MVE sâu 9 đến 10 tầng, tách khỏi pipeline số
nguyên."

**Nhớ thêm:**
- Điểm khác biệt lớn nhất với Cortex-A phải nói rõ: M85 không thực thi ngoài thứ
  tự. Nếu một lệnh bị khựng do chờ dữ liệu, các tầng liên quan sẽ tạm dừng theo
  quy tắc xác định, thay vì vượt rào chạy lệnh sau. Nhờ đó, phân tích thời gian
  thực thi dễ dự đoán hơn, dù độ trễ thực tế vẫn phụ thuộc bộ nhớ, cache và
  tranh chấp bus.
- Con số hiệu năng scalar: 6,28 CoreMark/MHz, cao hơn khoảng 18,7% so với 5,29
  của Cortex-M7. Đây là số sẽ gặp lại ở Chương IV, nên nói đúng một lần ở đây.

**Chuyển:** "Để dễ hình dung, xem một lệnh đi qua pipeline như thế nào."

---

## Slide 13 — Lệnh đi qua pipeline như thế nào?

**Trên slide:** Sơ đồ pipeline đơn giản hóa: front-end chung rồi rẽ 3 ống thực thi.

**Nói:**
"Front-end chung gồm IFU lấy lệnh qua PF và FE, rồi DPU phát lệnh qua DE, FD và
ISS. Từ đây lệnh rẽ sang ba ống: lệnh số nguyên đi qua EX1 đến EX3 rồi ghi kết
quả, tổng cộng 7 tầng. Lệnh dấu phẩy động và vector đi qua E1 đến E5, tổng cộng
9 đến 10 tầng. Lệnh load và store đi qua LSU, từ LS1 đến LS3. Vòng lặp chi phí
thấp nằm ngay ở khối lấy lệnh, giúp giảm chi phí rẽ nhánh cuối vòng lặp."

**Nhớ thêm:**
- Slide này là slide "giải thích lại bằng hình đơn giản", nên nói chậm và chỉ tay
  theo luồng: front-end → rẽ 3 ống → ghi kết quả. Đừng đọc lại hết slide 12.
- Nhắc lại: triple-issue chỉ là "chọn lọc", gắn với kỹ thuật Branch Folding ở
  tầng FD, không phải lúc nào cũng phát 3 lệnh.

**Chuyển:** "Xong pipeline, sang bộ nhớ gắn sát nhân: TCM."

---

## Slide 14 — ITCM/DTCM: bộ nhớ gắn sát nhân

**Trên slide:** Sơ đồ cầu nối TCM do nhóm vẽ; các ý ITCM 1 ngân hàng, DTCM 4 ngân hàng, IP tới 16 MB, S-AHB.

**Nói:**
"ITCM chỉ có một ngân hàng nên mỗi chu kỳ chỉ phục vụ một truy cập, trong khi
DTCM có 4 ngân hàng, cho phép CPU và DMA truy cập chồng lấn trong giới hạn bền
vững. Cổng S-AHB cho phép DMA nạp dữ liệu vào TCM mà không cần CPU tham gia
truyền dữ liệu, nhờ đó dữ liệu thời gian thực vẫn được nạp trong khi CPU tiếp
tục thực thi. Kết luận: TCM là bộ nhớ nhanh và xác định cho mã và dữ liệu tới
hạn."

**Nhớ thêm:**
- Đây là slide dễ bị hỏi nhất, phải phân biệt rõ hai mức số: mức IP và mức chip.
  IP cho phép tới 16 MB mỗi loại ITCM/DTCM và cache 0–64 KB có ECC tùy cấu hình,
  nhưng trên RA8M1 thực tế chỉ là 64 KB ITCM + 64 KB DTCM và cache 16 KB mỗi bên.
  Nói lẫn hai mức này là sai ngay.
- Sơ đồ này là do nhóm vẽ minh họa theo Optimization Guide, dung lượng trong
  hình là mức tối đa của IP, không phải cấu hình của RA8M1.

**Chuyển:** "Có bộ nhớ nhanh rồi, còn cần cơ chế bảo vệ và bus để nối ra ngoài."

---

## Slide 15 — MPU và bus

**Trên slide:** Sơ đồ minh họa MPU và bus do nhóm vẽ; các ý MPU PMSAv8 16 vùng, AXI 64-bit, AHB 32-bit, coprocessor 64-bit.

**Nói:**
"Bảo vệ bộ nhớ dùng MPU theo PMSAv8, là khối tùy chọn với tối đa 16 vùng theo
cấu hình IP, và khi bật TrustZone thì MPU tách riêng cho thế giới Secure và
Non-secure. Bus hệ thống chính dùng AMBA 5 AXI 64-bit ra bộ nhớ ngoài, bus
ngoại vi dùng AHB 32-bit, giao diện coprocessor 64-bit cho phép gắn tối đa 8 đơn
vị tăng tốc tùy biến."

**Nhớ thêm:**
- Câu cảnh báo trên slide phải nói rõ: bề rộng bus không bằng thông lượng.
  Thông lượng thực tế còn phụ thuộc tần số bus, độ trễ bộ nhớ, burst và tranh
  chấp bus. Vì vậy không thể suy ra một thông lượng cố định mỗi chu kỳ chỉ từ
  "64-bit".
- Khi tải vector nặng mà bus hẹp, EPU có thể rơi vào tình trạng chờ dữ liệu,
  tức là data starvation — nhưng đó là trường hợp phụ thuộc workload và cấu
  hình, không phải kết luận chung cho mọi chương trình.

**Chuyển:** "Bây giờ đến phần làm nên tên tuổi của M85 trong AI biên: Helium."

---

## Slide 16 — Helium: một lệnh, nhiều phần tử

**Trên slide:** Hình beats Helium; các ý vector 128-bit = 4 beat, dual-beat, 8 MAC 8-bit, nhanh hơn M7 khoảng 4 lần ML và 3 lần DSP.

**Nói:**
"Helium, tên chính thức là M-Profile Vector Extension, là mở rộng vector 128-bit
cho dòng M. Một phép toán vector 128-bit được chia làm 4 beat, mỗi beat 32-bit.
M85 triển khai dual-beat, tức xử lý đồng thời 2 beat, tương đương 64-bit dữ liệu,
trong một chu kỳ. Ở dạng này, tối đa đạt 8 phép MAC 8-bit mỗi chu kỳ. ARM công bố
hiệu năng ML cao gấp khoảng 4 lần và DSP gấp khoảng 3 lần so với Cortex-M7, và
nhanh hơn khoảng 20% so với Cortex-M55 cũng có Helium."

**Nhớ thêm:**
- Phải nói "trong điều kiện lý tưởng" và "công bố của ARM" khi nhắc các con số
  4 lần, 3 lần, 20%. Đây là thông lượng kiến trúc, không phải cam kết mọi lệnh
  MVE đều đạt đúng 2 chu kỳ, vì độ trễ còn phụ thuộc loại lệnh, dữ liệu và bộ nhớ.
- Một lệnh vector duy nhất xử lý đồng thời nhiều phần tử: mỗi thanh ghi vector
  chứa 16 lane 8-bit, 8 lane 16-bit, 4 lane 32-bit hoặc 2 lane 64-bit.

**Chuyển:** "Điểm hay nhất của Helium không chỉ là rộng, mà là gối đầu được."

---

## Slide 17 — Gối đầu theo beat

**Trên slide:** Cùng hình beats; các ý beat-wise overlapping, lane predication, gather/scatter, compiler vector hóa một phần.

**Nói:**
"Nhờ gối đầu theo beat, ngay khi lệnh nạp VLDR vừa tải xong nửa đầu dữ liệu,
tức là beat A và B, thì lệnh nhân-cộng dồn VMLA kế tiếp lập tức được đưa vào
thực thi trên hai beat vừa nạp, mà không cần đợi VLDR chạy xong cả 128-bit.
Ngoài ra, Helium còn có lane predication, tức là bật hoặc tắt tính toán trên
từng lane riêng lẻ, và lệnh gom/rải dữ liệu giúp vector hóa một số mẫu truy cập
không liên tục."

**Nhớ thêm:**
- Hai câu rào quan trọng: trình biên dịch có thể tự vector hóa một phần mã C/C++
  thông thường, nhưng mã viết tay bằng intrinsic hoặc CMSIS-DSP giúp kiểm soát
  các đoạn quan trọng hơn — và lợi ích thực tế vẫn cần đo kiểm, không suy ra
  từ thông lượng lý thuyết.
- Đừng nói "không còn thời gian chờ" — nói "giảm thời gian chờ giữa tải và tính
  toán", vì chồng lấn còn phụ thuộc bố trí dữ liệu và khả năng chồng lấn lệnh.

**Chuyển:** "Mạnh rồi, giờ phải an toàn: sang bảo mật."

---

## Slide 18 — TrustZone: hai thế giới thực thi

**Trên slide:** Sơ đồ TrustZone do nhóm vẽ lại; các ý Secure/Non-secure, SAU, IDAU, NSC/SG.

**Nói:**
"TrustZone cho Armv8-M chia hệ thống thành hai thế giới thực thi Secure và
Non-secure bằng phần cứng. Đơn vị SAU do mã Secure lập trình, tối đa 8 vùng,
cùng với IDAU do hãng chip định nghĩa, quyết định mỗi vùng địa chỉ, ngoại vi và
ngắt thuộc về thế giới nào. Mã Non-secure chỉ gọi vào Secure qua vùng NSC bằng
lệnh SG, và mỗi thế giới có MPU, SysTick và bảng vector ngắt riêng. Nền tảng này
dùng để cất khóa, chạy firmware tin cậy và làm gốc tin cậy cho secure boot."

**Nhớ thêm:**
- Sơ đồ này là do nhóm vẽ lại theo kiến trúc Armv8-M, không phải hình gốc của
  Arm — nếu thầy hỏi nguồn hình thì trả lời đúng như vậy.
- Khi quay về từ Secure, mã dùng lệnh BXNS. Chi tiết này không có trên slide
  nhưng rất hay được hỏi kèm với SG.

**Chuyển:** "Chia hai thế giới rồi, còn phải chống kẻ tấn công lái luồng thực thi ngay trong một thế giới."

---

## Slide 19 — PACBTI: chống ROP và JOP

**Trên slide:** Sơ đồ PAC-RET do nhóm vẽ; các ý theo đúng thứ tự báo cáo §3.4: tấn công trước, cơ chế sau — ROP rồi PAC-RET, JOP rồi BTI.

**Nói:**
"Trong tấn công ROP, kẻ tấn công ghi đè địa chỉ trả về trên ngăn xếp để lái
chương trình nhảy tới các đoạn mã có sẵn và xâu chuỗi chúng lại. PAC-RET ngăn
việc này bằng cách ký địa chỉ trả về trong thanh ghi LR, dùng bộ điều biến là
con trỏ ngăn xếp SP, và mã PAC được lưu trong thanh ghi R12. Khi hàm quay lại,
lệnh AUT sẽ kiểm tra chữ ký; địa chỉ bị ghi đè sẽ không qua kiểm tra và gây
lỗi, thay vì âm thầm chạy tiếp. Còn trong tấn công JOP, kẻ tấn công lợi dụng
các lệnh rẽ nhánh gián tiếp để chuyển hướng luồng chạy. BTI giới hạn đích đến
của rẽ nhánh gián tiếp: đích hợp lệ phải là một landing pad, nếu không sẽ gây
lỗi, nhờ đó hạn chế JOP."

**Nhớ thêm:**
- Ba điểm phải nói nếu thầy hỏi sâu: thứ nhất, PAC lưu ở R12 theo tài liệu
  PACBTI Extensions 109576, không phải ở các bit cao của LR. Thứ hai, trình biên
  dịch có thể sinh mã PACBTI qua tùy chọn -mbranch-protection, nhưng chỉ bật cờ
  biên dịch là chưa đủ — còn phụ thuộc toolchain, thư viện, mã assembly viết tay
  và cấu hình CONTROL cho từng trạng thái bảo mật và mức đặc quyền. Thứ ba,
  PACBTI là mở rộng tùy chọn của Armv8.1-M, và M85 là nhân đầu tiên trong họ M
  tích hợp nó.
- Sơ đồ là do nhóm vẽ minh họa theo tài liệu 109576, nói rõ nguồn này khi trình bày.

**Chuyển:** "Cuối phần kiến trúc: ngắt, debug và an toàn chức năng."

---

## Slide 20 — Ngắt, debug và an toàn chức năng

**Trên slide:** Sơ đồ tổng quát hệ thống quanh nhân M85; các ý NVIC 480 ngắt, CoreSight, EWIC, DCLS.

**Nói:**
"NVIC của M85 hỗ trợ tới 480 ngắt ngoài, giữ nguyên các cơ chế thời gian thực
của dòng M: tail-chaining, late-arrival cho ngắt ưu tiên cao đến muộn, và độ ưu
tiên lồng nhau. Hệ thống debug CoreSight gồm ETM trace lệnh, DWT điểm theo dõi,
ITM và PMU đo hiệu năng. EWIC qua Core EPPB đánh thức hệ thống từ trạng thái
ngủ sâu, còn Debug EPPB nối ra CoreSight. Tùy chọn dual-core lock-step chạy hai
bản sao logic nhân để so sánh và phát hiện lỗi, phục vụ ứng dụng ô tô và công
nghiệp yêu cầu an toàn chức năng."

**Nhớ thêm:**
- Phân biệt rõ: 480 là giới hạn cấu hình tối đa của IP, không phải mọi chip đều
  có đủ 480 ngắt ngoài. Tương tự, DCLS là tùy chọn của IP, và slide 21 sẽ nói rõ
  là chỉ xét ở mức IP, không mặc định RA8M1 có.
- Sơ đồ này từng dùng làm Hình 2.2 trong báo cáo, và có PMC-100 qua APB cho kiểm
  tra MBIST trực tuyến — chi tiết này chỉ nhắc nếu thầy hỏi về khối PMC-100,
  không cần kể hết trên slide.

**Chuyển:** "Vậy những cơ chế vừa rồi, khi thành chip thật thì khảo sát cái gì? Sang slide đối chiếu."

---

## Slide 21 — Đối chiếu sang RA8M1

**Trên slide:** Bảng hai cột: đặc điểm M85 đối chiếu với nội dung khảo sát trên RA8M1 ở Chương III.

**Nói:**
"Bảng này là cầu nối sang Chương III, và cũng là cách đọc đúng cả chương vừa
rồi. Pipeline 7 tầng và dual-issue thì sang Chương III sẽ khảo sát độ trễ ngắt
và thời gian thực thi thực tế. Helium dual-beat thì tăng tốc AI biên và DSP,
nhưng lưu ý là trên RA8M1 không dùng NPU ngoài nhân. ITCM, DTCM và cache có ECC
thì đặt mã và dữ liệu tới hạn vào TCM và phân tích độ trễ. Bus M-AXI và DMA qua
S-AHB thì nạp TCM trong khi CPU vẫn chạy. TrustZone thì phân vùng Secure và
Non-secure làm gốc secure boot. PACBTI thì bảo vệ luồng thực thi theo cấu hình
thực tế của chip. NVIC 480 ngắt thì xử lý ngắt thời gian thực trong ứng dụng
biên."

**Nhớ thêm:**
- Dòng cuối bảng là quan trọng nhất: các tính năng ghi "tùy chọn" là giới hạn
  cấu hình IP, không phải mọi chip đều bật đủ. Đặc biệt DCLS chỉ xét ở mức IP,
  RA8M1 có hay không thuộc phạm vi chip cụ thể, không được mặc định là có.
- Đây là slide "chốt chương bằng cầu nối", không phải slide kết luận chung.
  Đừng kết thúc bài ở đây — còn slide kết luận sau.

**Chuyển:** "Tóm lại toàn bộ chương II trong một slide."

---

## Slide 22 — Kết luận chương II

**Trên slide:** Các ý: M85 đỉnh họ M; vẫn là vi điều khiển; một nhân làm 3 việc; Chương III sang RA8M1; cảm ơn và Q&A.

**Nói:**
"Tóm lại, M85 là nhân mạnh nhất họ M về cả ba trục: hiệu năng scalar, vector
Helium và bảo mật TrustZone cùng PACBTI. Nhưng nó vẫn là một vi điều khiển:
thực thi đúng thứ tự, bộ nhớ TCM, NVIC độ trễ thấp, và không có MMU. Nói gọn
trong một câu: một nhân duy nhất vừa điều khiển thời gian thực, vừa chạy suy
luận AI biên, vừa tự bảo vệ luồng thực thi của mình. Sang Chương III, nhóm sẽ
xem Renesas hiện thực hóa nhân này thành con chip RA8M1 cụ thể như thế nào.
Cảm ơn thầy và các bạn đã lắng nghe. Em xin nhận câu hỏi thảo luận."

**Nhớ thêm — 3 câu hỏi hay gặp nhất, trả lời ngắn gọn:**
- *"M85 mạnh vậy sao không dùng Cortex-A cho rồi?"* — Vì bài toán biên cần tính
  tất định, chi phí và năng lượng của MCU. Cortex-A có MMU và hệ điều hành đầy
  đủ, nhưng mất tính tất định và tốn năng lượng hơn, không hợp với nút cảm biến.
- *"TCM 16 MB mà RA8M1 chỉ có 128 KB, có mâu thuẫn không?"* — Không. 16 MB là mức
  tối đa của IP mà Arm cho phép cấu hình, còn RA8M1 chọn cấu hình 64 KB ITCM +
  64 KB DTCM. Hai mức số này phải tách bạch.
- *"Helium có thay được NPU không?"* — Không hoàn toàn. Helium tăng tốc tốt các
  mô hình TinyML vừa, còn mô hình thị giác phức tạp hàng trăm triệu MAC mỗi giây
  vẫn cần NPU chuyên dụng như Ethos-U55 — nhưng đó là chuyện của RA8P1 ở Chương
  IV, không phải của RA8M1 ở Chương III.

---

*Kịch bản này bám theo nội dung thẻ Chương II trong Google Doc và bộ slide 22 trang
hiện tại. Các con số "tùy chọn / tối đa của IP" đã được tách khỏi "cấu hình thực tế
của RA8M1" đúng như trong báo cáo — khi nói, đừng gộp hai mức này lại với nhau.*
