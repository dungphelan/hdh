# LOG SỬA SLIDE CHƯƠNG II — CORTEX-M85
Ghi trung thực mọi lần sửa, kể cả lỗi do chính người làm gây ra.
Nguồn nội dung: Thẻ 2 (Tab 2) của Google Doc báo cáo M85.
Template: ảnh nền SLIDE_DUY/HGello.jpg (thanh xanh + logo PTIT, 16:9).

## 2026-11-01 ~19:00 — Bản dựng đầu (v1, 23 slide)
- Chuyển toàn bộ Chương II thành 23 slide Beamer (main.tex), bố cục ảnh
  trái / nội dung phải, tiêu đề trong thanh xanh, mỗi slide tối đa 6 ý.
- Biên dịch lần đầu BỊ LỖI, không ra PDF: 14 dòng `\end{frame}` /
  `\end{itemize}` bị sai ký tự đóng ngoặc (thành dấu `>`) — lỗi do bản
  thảo đầu, đã quét toàn file và sửa hết trước khi biên dịch lại.
  (Bài học: khi deck báo "File ended while scanning use of \frame",
  kiểm tra ký tự đóng ngoặc của các lệnh \end trước tiên.)
- Lỗi thứ hai ở v1: tiêu đề bị cắt ở mép trên và một số tiêu đề dài bị
  tràn xuống dòng thứ hai nhưng dòng thứ hai nằm ngoài thanh xanh nên
  không nhìn thấy (chữ trắng trên nền trắng). Nguyên nhân: thanh xanh
  chỉ cao ~1,17 cm trên slide 16x9 cm, trong khi vị trí tiêu đề đặt
  yshift -1,12 cm rồi -1,55 cm đều sai.
- Đã đo thử bằng file test với 5 mức yshift khác nhau và chốt
  yshift = -0,58 cm (đúng giữa thanh xanh), cỡ chữ tiêu đề 17pt, đồng
  thời rút ngắn các tiêu đề dài (ví dụ tiêu đề trang bìa từ
  "CHƯƠNG II. BỘ XỬ LÝ NHÚNG & CORTEX-M85" thành "CHƯƠNG II. ARM CORTEX-M85";
  phần tên đầy đủ của chương vẫn nằm ở dòng phụ đề bên dưới).
- Bảng đối sánh (slide 10) bị tràn phải 59pt: đã sửa bằng cỡ chữ
  footnotesize, tabcolsep 4pt và rút gọn ô "7 tầng int, 9–10 FP/MVE".
- Hai cảnh báo tràn dọc nhỏ còn lại (6,5pt và 10,8pt ở slide MCU/MPU và
  TrustZone) đã kiểm tra bằng ảnh render: nội dung vẫn hiện đầy đủ,
  không bị cắt ở đáy trang — ghi nhận ở đây để lần sửa sau đối chiếu.
- Render-check toàn bộ 23 trang ở 100 dpi trước khi giao (tiêu đề trong
  thanh xanh, ảnh trái, nội dung phải, số trang ở góc dưới phải).
- Kết quả: main.pdf 23 trang, 16:9, đã đính kèm cùng file zip.

## 2026-11-01 ~02:01 — Lưu lên Drive SLIDE_DUY
- Đã tải lên folder SLIDE_DUY (1ApXDeGCFs8t7sCyeIuMLT0jMyL25DcGe):
  - Chuong-II-Cortex-M85-slide-thuyet-trinh.pdf (id 1wMJb6WFkPmc6qGxZcWBvsUO5ecUcTZvS)
  - ch2-slides.zip (id 1nTOSN0GKMWFrmGhJezr75RB_nooZG6_F)
- Đã kiểm tra lại bằng lệnh liệt kê folder: cả 2 file đều có mặt.

## 2026-11-01 ~02:02 — Gửi Gemini vòng 1 (đang chạy)
- Tài khoản: Ash Red (chocong040406@gmail.com), đoạn chat MỚI (không dùng
  lại chat cũ để tránh loãng context), tải đúng 1 lần file PDF.
- Câu hỏi gửi kèm: nhận xét về KISS, quy tắc 6x6 (slide nào vi phạm và
  sửa thế nào), nội dung đủ/thừa/thiếu, bố cục ảnh trái — nội dung phải,
  điểm tổng thể và 5 sửa đổi ưu tiên cao nhất.
- Lưu ý về kiểm tra đăng nhập: lần kiểm tra lúc 01:51 báo chưa có tài
  khoản nào đăng nhập, nhưng người dùng xác nhận lúc 02:00 là đã đăng
  nhập rồi — kết quả kiểm tra cũ đã lỗi thời, không dùng làm căn cứ nữa;
  vòng Gemini đang chạy sẽ tự xác nhận lại trạng thái đăng nhập khi thực hiện.

## Quy tắc làm việc tiếp theo (theo lệnh người dùng lúc 02:05)
- Trao đổi với Gemini NHIỀU VÒNG cho tới khi thấy đủ, không chỉ 1 lần.
  Mỗi vòng: chat mới + tải lại bản PDF mới nhất (không tải nhiều lần
  vào cùng một chat).
- Mỗi lần sửa xong đều render-check lại toàn bộ trang, đặc biệt soi lỗi
  chữ tràn khỏi khung (out of border): tiêu đề trong thanh xanh, bảng,
  và các bullet dài. Lỗi nào phát hiện đều ghi vào log này, không giấu.
- Mọi lần sửa đều ghi vào log này ngay sau khi làm, kể cả sửa nhỏ.
- Phạm vi: chỉ sửa bộ slide; tài liệu báo cáo (Thẻ 2) không động tới
  nếu người dùng không bảo khác.

## 2026-11-01 ~02:05 — Gemini vòng 1: 7,5/10 (chat mới, tài khoản Ash Red)
- Chat: "Đánh giá slide ARM Cortex-M85", https://gemini.google.com/app/f5418a2957e4f754
- Tóm tắt nhận xét (diễn đạt lại, không trích nguyên văn): nội dung/kỹ thuật
  9/10, trình bày/hình ảnh chỉ 6/10 — bộ slide sâu, chính xác, mạch lạc,
  nhưng còn nặng chữ, chưa hợp để thuyết trình. Các slide dài kiểu văn xuôi:
  5, 8, 11, 18, 19; gần như mọi slide đều vi phạm 6x6 (chủ yếu vượt 6 từ/ý);
  nặng nhất: slide 4 (10–14 từ/ý), 5, 9, 18 (12–18 từ/dòng), 19.
- 5 sửa đổi ưu tiên Gemini đưa ra: (1) ép 6x6 toàn bộ, (2) gộp 10+11 và
  13+14, (3) gộp 21+22, (4) tách 19 thành TrustZone + PACBTI kèm sơ đồ
  PAC-RET, (5) phóng to hình ở slide 3, 13, 17.

## 2026-11-01 ~02:30 — Sửa theo vòng 1, thành bản v2 (23 slide)
- ĐÃ ÁP DỤNG:
  - Rút gọn toàn bộ bullet thành cụm từ ngắn (không còn câu văn xuôi dài),
    giữ đủ số liệu và thuật ngữ then chốt.
  - Tách slide 19 thành 19a TrustZone + 19b PACBTI, kèm sơ đồ PAC-RET do
    nhóm tác giả vẽ (fig_pacbti.png): LR + SP (bộ điều biến) -> PAC lưu
    ở R12 -> AUT kiểm tra khi quay lại, sai -> lỗi; BTI: đích rẽ nhánh
    gián tiếp phải là landing pad. Các chi tiết đã đối chiếu với tài liệu
    PACBTI 109576 (không dùng kiểu PAC nhúng trong LR của profile A).
  - Gộp 2 slide đối chiếu RA8M1 thành 1 slide bảng 8 hàng (slide 22 mới);
    render-check cho thấy bảng vừa trang, không nhét.
  - Hình pipeline (13) và beats (17) chuyển sang bố cục hình trên —
    nội dung dưới 2 cột, hình thu còn 0,55 chiều rộng; chú thích rút còn
    1 dòng; hình Von Neumann/Harvard (slide 3) giữ nguyên vì vốn đã vừa.
  - Slide 11 (điểm nhấn) cắt từ 6 ý còn 4 ý, bỏ các ý chỉ nhắc lại bảng;
    slide 14 (bốn đơn vị) bỏ dòng CoreMark trùng với slide 11.
- KHÔNG ÁP DỤNG (ghi rõ lý do, để Gemini vòng 2 và người dùng đối chiếu):
  - Không gộp 10+11 và 13+14 thành 1 slide: bảng 6 cột thu về nửa trang sẽ
    không đọc được, và pipeline + 6 bullet dồn 1 trang sẽ tràn khung —
    đúng lỗi người dùng dặn phải tránh. Thay vào đó là cắt gọn nội dung
    trùng lặp ở slide 11 và 14.
  - Không thêm bảng tổng hợp "tần số tối đa, công nghệ tiến trình,
    công suất/MHz" của M85: các số này không có trong Chương II và chưa
    xác minh được từ nguồn chính thức; tần số 480 MHz là của chip RA8M1,
    không phải của IP M85. Thêm vào sẽ là bịa số.
- LỖI TRÀN KHUNG PHÁT HIỆN VÀ SỬA Ở v2 (ghi trung thực):
  - Bản v2 lần 1: slide 13 (pipeline) mất dòng bullet cuối ở mép dưới,
    slide 17 (beats) mất 3 bullet dưới mép trang — do hình trên 0,78
    chiều rộng quá cao cộng chú thích 2 dòng.
  - Sửa lần 2: bullet 2 cột vẫn chưa đủ — vẫn tràn (pipeline 21pt, beats
    60pt theo log biên dịch).
  - Sửa lần 3: thu hình còn 0,55 chiều rộng + chú thích 1 dòng — pipeline
    hết tràn; beats còn tràn 19pt do bullet cuối "8/4/2 MAC" xuống 2 dòng.
  - Sửa lần 4: rút bullet đó còn "8 MAC 8-bit mỗi chu kỳ" (1 dòng) —
    beats hết tràn. Bản cuối còn 3 cảnh báo tràn nhỏ (4pt, 5,8pt, 10,8pt
    ở các slide MCU/MPU, beats, PACBTI) nhưng render-check cho thấy mọi
    nội dung đều hiện đầy đủ, không bị cắt — ghi nhận để vòng sau soi lại.
- Render-check bản v2 cuối: xem trực tiếp các trang 3, 6, 13, 15, 17,
  19, 20, 22 — tiêu đề trong thanh xanh, không trang nào bị cắt chữ.
  Tổng: 23 slide (tách +1, gộp -1).

## 2026-11-01 ~02:12 — Gemini vòng 2: 8,8/10 (chat mới, tài khoản Ash Red)
- Chat: "Đánh giá slide v2", https://gemini.google.com/app/247c38feb70bfb4a
- Lưu ý về số liệu: báo cáo của vòng 2 ghi "tăng từ 6,5/10 ở vòng 1" là
  SAI — điểm vòng 1 của bộ slide là 7,5/10 (6,5 là điểm của vòng nhận xét
  báo cáo, một việc khác). Chuỗi đúng: slide v1 7,5 -> v2 8,8.
- Tóm tắt nhận xét (diễn đạt lại): 6x6 cơ bản đã đạt; bố cục hình trên —
  nội dung dưới 2 cột của slide pipeline và beats được đánh giá rất tốt;
  slide PACBTI mới rõ ràng, phân biệt được PAC-RET (chống ROP) với BTI
  (chống JOP). Còn lại: slide 15, 16, 19 còn 7 dòng hiển thị; slide 21
  quá thưa; chú thích trong sơ đồ TCM bị chồng lấn; chú thích nguồn
  slide 7 sát mép dưới; ghi chú hàng DCLS ở bảng 22 trôi ở mép bảng.

## 2026-11-01 ~02:35 — Sửa theo vòng 2, thành bản v3 (23 slide)
- Sơ đồ TCM vẽ lại (v3, chỉ cho slide — tài liệu báo cáo vẫn dùng bản v2
  đã nhúng, không động tới): chân chú thích tách thành 2 dòng, cỡ chữ
  lớn hơn, khoảng trống rõ ràng dưới các hộp; render-check không còn
  chồng lấn.
- Sơ đồ PAC-RET vẽ lại: nhãn "Modifier (SP)" thay cho "modifier"; thêm
  mũi tên từ hộp LR đi vòng qua lề trái vào khối AUT, ghi "LR
  re-validated" — không cắt qua hộp SP.
- Slide 15: 5 ý -> 4 ý (bỏ dòng về cache miss, nội dung này người thuyết
  trình nói miệng).
- Slide 16: 6 ý -> 5 ý, gộp AXI/AHB/coprocessor thành 1 ý, dòng cuối rút
  thành "nghẽn dữ liệu ở EPU".
- Slide 19a TrustZone: giữ 5 ý nhưng rút ngắn từng dòng cho khỏi xuống
  dòng thứ hai.
- Slide 21 NVIC: làm giàu thay vì để thưa — CoreSight ghi rõ ETM trace
  lệnh, DWT điểm theo dõi; thêm ý EWIC/EPPB (đánh thức từ sleep, debug
  qua bus riêng — đã xác minh ở Chương II); tổng 6 ý.
- Slide 22: ô DCLS rút thành "Chỉ xét ở mức IP, theo cấu hình chip";
  ghi chú về tính năng tùy chọn chuyển thành dòng chú thích riêng dưới
  bảng, cách xa mép bảng.
- Slide 7: chú thích nguồn tăng từ footnotesize lên small (chỉ slide này,
  không đổi macro chung để khỏi đẩy tràn các slide khác).
- SỰ CỐ TRONG LÚC SỬA (ghi trung thực): lần vá đầu tiên bằng script
  heredoc bị lỗi cú pháp Python ở dòng chứa ký tự `\` của bảng LaTeX
  nên toàn bộ lần vá đó không chạy — file main.tex vẫn là bản v2 và bản
  PDF biên dịch ra vẫn là v2. Đã phát hiện nhờ đối chiếu số dòng và làm
  lại từng chỗ bằng sửa trực tiếp, sau đó biên dịch lại và render-check
  lại các trang 15, 16, 22 mới xác nhận v3 thật.
- Render-check v3: trang 15 (chân chú thích TCM tách rõ, không chồng),
  16 (5 ý, mỗi ý 1 dòng), 22 (ghi chú dưới bảng, cách mép bảng) đều sạch.
  Ba cảnh báo tràn nhỏ cũ (4pt, 5,8pt, 10,8pt) vẫn còn trong log biên
  dịch nhưng các trang tương ứng đã xem trực tiếp và không bị cắt chữ.

## 2026-11-01 ~02:17 — Gemini vòng 3: 8,5/10, kết luận READY TO PRESENT (chat mới, Ash Red)
- Chat: "Rà soát slide v3", https://gemini.google.com/app/15bb48086f8d53a1
- Điểm vòng 3 (8,5) thấp hơn vòng 2 (8,8) nhưng kết luận rõ ràng: bản v3
  đã đạt chuẩn báo cáo đồ án/chuyên đề ở trường, không còn sửa đổi nào
  bắt buộc nếu gấp; các mục còn lại chỉ để lên mức "Pro".
- Gemini xác nhận đã sửa xong: chân chú thích TCM tách 2 dòng không chồng;
  mũi tên LR vào AUT và nhãn Modifier (SP) rõ; ô DCLS và ghi chú bảng 22
  đặt đúng chỗ.
- KIỂM CHỨNG CÁC "LỖI LATEX NGHIÊM TRỌNG" GEMINI BÁO — ĐỀU LÀ ĐỌC SAI:
  - Slide 1 "$V_{!}$ thay cho Vị trí": ảnh render trang 1 cho thấy dòng
    "Phân loại | Vị trí của M85 | Kiến trúc chuyên sâu" hiển thị ĐÚNG.
    Trong mã nguồn cũng là chữ thường, không có công thức toán nào.
  - Slide 10 "$Co^{*}$": ảnh render trang 10 cho thấy "Có*" đúng ở mọi
    cột; ô "7 int, 9–10 FP/MVE" đọc được, chỉ hơi chật.
  - Slide 22 "$NSC/SG)$ thiếu ngoặc mở": ảnh render trang 22 cho thấy
    "TrustZone (SAU/IDAU, NSC/SG)" đủ ngoặc.
  - Kết luận: đây là lỗi đọc của Gemini với chữ có dấu tiếng Việt ở cỡ
    nhỏ (cùng kiểu lỗi đã gặp ở các vòng nhận xét báo cáo) — KHÔNG sửa
    các ô đó, vì sửa theo đọc sai sẽ làm hỏng dữ liệu đúng.
  - Slide 12 "MAU chồng viền đứt của EPU": đây là chi tiết TRONG HÌNH GỐC
    của Arm, không phải lỗi do nhóm tác giả vẽ; che nó đi tức là sửa hình
    gốc — vi phạm quy tắc hình ảnh của người dùng. Giữ nguyên.

## 2026-11-01 ~02:30 — Bản v4 (bản cuối) và QUYẾT ĐỊNH DỪNG VÒNG LẶP
- Chỉ sửa 2 thứ có thật:
  - Chú thích nguồn/hình ở mọi slide: đổi màu từ gray sang black!70
    (đậm hơn, đọc được từ xa) — đổi màu không làm đổi chiều cao nên
    không gây tràn khung; đã render-check lại trang 15.
  - Slide 23: câu kết "Cảm ơn — câu hỏi thảo luận?" (lủng củng thật)
    đổi thành "Cảm ơn thầy và các bạn đã lắng nghe!" + "Thảo luận &
    Câu hỏi (Q&A)".
- KHÔNG sửa thêm: dòng CoreSight ở slide 21 (vòng 2 bảo thêm chi tiết,
  vòng 3 lại bảo nhiều chữ — nghe cả hai vòng sẽ thành vòng lặp vô hạn,
  giữ bản đã làm giàu theo vòng 2); slide 8 (Gemini tự nhận là chấp
  nhận được).
- QUYẾT ĐỊNH DỪNG: Gemini đã kết luận READY TO PRESENT ở v3; v4 chỉ
  cộng thêm 2 sửa nhỏ có thật. Vòng 4 sẽ chỉ lặp lại tranh luận về cỡ
  chữ chú thích và số từ/ý — không còn lỗi hiển thị nghiêm trọng nào.
  Theo lệnh "trao đổi cho tới khi thấy đủ", tới đây là ĐỦ. Nếu người
  dùng muốn lên 9,5+ thì cần quyết định khác (ví dụ: vẽ lại hình gốc
  của Arm ở slide 12), không phải thêm một vòng Gemini nữa.
- Render-check v4: trang 23 (câu kết mới) và trang 15 (chú thích đậm
  hơn) đều sạch; 23 slide; 3 cảnh báo tràn nhỏ cũ (4pt, 5,8pt, 10,8pt)
  vẫn chỉ là cảnh báo — các trang tương ứng đã xem trực tiếp, không
  bị cắt chữ.

## 2026-11-01 ~12:10 — 12 comment của người dùng trên PDF v4 + 2 ảnh mới
- Đã đọc đủ 12 comment trên file PDF trong SLIDE_DUY (trang PDF = số
  comment + 1 do anchor 0-based). Nội dung sửa theo từng comment ở mục v5
  dưới đây. Các comment KHÔNG được đánh dấu resolved trên Drive — để
  người dùng tự kiểm tra bản mới rồi quyết.
- Ảnh 1 (scatter Traditional & ML): đã xác minh là biểu đồ của Arm
  (tài liệu giới thiệu Cortex-M85, © 2023 Arm: "best in class performance
  for both traditional and ML workloads") — dùng được với chú thích
  nguồn Arm (2023). Không trích số % chính xác trong bullet vì mốc
  chuẩn hóa của trục không ghi rõ trên ảnh crop; chỉ diễn tả vị trí
  tương đối (M85 góc trên-phải, cao nhất cả hai trục).
- Ảnh 2 (pipeline đơn giản Prefetch→3 ống): KHÔNG phải Figure 2-2 của
  Optimization Guide 107950 (hình đó là sơ đồ chi tiết IFU/DPU/LSU/EPU
  đã có ở slide pipeline) — đây là hình đơn giản hóa khác, không xác
  định được chính xác tài liệu gốc sau một lần tìm kiếm nên chú thích
  ghi rõ "hình đơn giản hóa do người dùng cung cấp", không gán nguồn
  Arm mà chưa kiểm chứng. Hình này bổ sung, không thay thế hình chi
  tiết: slide pipeline giữ hình Guide, slide đơn vị thực thi dùng hình
  đơn giản để demo đường đi của lệnh.

## 2026-11-01 — Bản v5 (22 slide, gộp 10+11 nên giảm 1 so với v4)
- Slide 5 RISC/CISC: bỏ bullet, thay bằng bảng đối chiếu 3 hàng
  (lệnh / truy cập nhớ / thời gian chạy) + dòng ⇒ "M85 dùng Thumb-2
  thuộc trường phái RISC" + lưu ý tất định.
- Slide 6 MCU/MPU: ý "Chạy bare-metal/RTOS" lùi thành ý con của MCU,
  ý "Nhiều MPU dùng MMU" lùi thành ý con của MPU (đúng 2 vị trí anchor
  của comment); bổ sung tên đầy đủ Microcontroller Unit /
  Microprocessor Unit (comment ghi "Microcontrol Unit" — đã sửa thành
  dạng chuẩn Microcontroller Unit).
- Slide 9 Edge AI: thêm ảnh scatter bên trái (giới hạn chiều cao 5,2cm
  để ảnh vuông không tràn khung) + bullet ⇒ về vị trí M85.
- Slide 10: GỘP slide điểm nhấn cũ vào cùng slide bảng theo đúng yêu
  cầu: ô đỏ (\fcolorbox) khoanh cặp đối chiếu trực tiếp — CoreMark M7
  5,29 với M85 6,28; Helium M55 Single-beat với M85 Dual-beat — cộng
  dòng ⇒ tóm tắt. Slide điểm nhấn riêng cũ bị xóa.
- Slide 10 + 21 căn lề bảng: bảng RA8M1 dùng \vfill trên/dưới để căn
  giữa dọc (hết "lệch trên"); bảng đối sánh sửa triệt để xem mục dưới.
- Slide 13 (đơn vị thực thi): thêm ảnh pipeline đơn giản lên trên +
  2 đường đi: lệnh số nguyên DPU→EX1–EX3→ghi kết quả (7 tầng),
  lệnh FP/vector DPU→E1–E5→ghi kết quả (9–10 tầng), load/store qua LSU.
- Slide 14 TCM: dòng ⇒ chuyển thành bullet cuối trong cột phải (bản
  đầu đặt dưới 2 cột bị cắt ở mép dưới — đã sửa).
- Slide 15 MPU/bus: vẽ sơ đồ MPU mới (CPU→MPU Secure/Non-secure→AXI
  64-bit ra bộ nhớ ngoài / AHB 32-bit ra ngoại vi) + bullet viết thành
  câu đầy đủ thay cho cụm từ cụt. Bản đầu đặt hình lên trên + bullet
  2 cột bị tràn khung nên chuyển sang bố cục ảnh trái — bullet phải.
  (Sự cố khi vẽ: nhãn AXI/AHB bản đầu bị hộp đè mất chữ vì vẽ nhãn
  trước hộp; đã sửa bằng cách vẽ hộp trước, nhãn sau, nới rộng khe.)
- Slide 17 gối đầu theo beat: chèn lại ảnh beats vào cột trái.
- Slide 20 NVIC: bê lại sơ đồ tổng quát hệ thống cũ (fig_m85_system,
  từng là Hình 2.2 trong báo cáo: Processor, AXI, S-AHB/DMA, ITCM/DTCM,
  Debug EPPB, Core EPPB→EWIC, PMC-100 APB) vào cột trái để người thuyết
  trình chỉ được EWIC/EPPB/PMC-100; bullet phải thêm 2 ý EWIC và Debug
  EPPB→CoreSight.
- LỖI BẢNG LỆCH LÊN HEADER (slide 10) — ĐIỀU TRA TRUNG THỰC: thử lần
  lượt frame [t], thêm \vspace, đổi tabular sang [t] — cả ba đều KHÔNG
  đổi vị trí bảng. Thí nghiệm đối chứng 3 trang (bản sao y slide 10 /
  chỉ bảng / bản sao y + \vspace*{-1cm}) mới chỉ ra nguyên nhân: nội
  dung slide này quá cao nên cơ chế căn giữa dọc của Beamer đẩy cả
  khối lên chạm header; bản chỉ có bảng thì sạch, bản trừ 1cm thì sạch.
  Cách sửa chốt: \vspace*{-1cm} sau tiêu đề slide 10 (đã render-check:
  bảng nằm dưới thanh xanh, đủ khe hở, caption + dòng ⇒ hiện đủ).
  Áp dụng [t] cho cả 3 bảng để neo đỉnh bảng, phòng tái phát.
- Render-check v5 cuối: xem trực tiếp các trang 5, 6, 9, 10, 13, 14,
  15, 17, 20, 21 — không trang nào bị cắt chữ hay chồng header; các
  cảnh báo tràn còn lại (4–18,7pt) đều đã xem trực tiếp và không cắt
  nội dung.
- Chưa sửa theo ý "phần phân chia còn bị kém": đã hiểu là 2 chỗ phân
  chia đã có comment (ý con MCU/MPU và bảng RISC/CISC). Nếu người dùng
  ý nói phân vùng Secure/Non-secure của TrustZone thì cần bảo thêm —
  slide TrustZone hiện chỉ có hình phân vùng, chưa có hình minh họa
  riêng cho SAU/IDAU.

## 2026-11-01 — Bản v6 (24 slide: +1 slide mốc tiến hóa, +1 tách MPU/bus)
- 4 comment mới trên PDF v5 (12:37–12:40, trang PDF 9/10/12/15):
  1. Trang 9 (Edge AI, cột phải cuối): "Có dấu => thì bỏ tam giác xanh"
     → dòng ⇒ đã tách khỏi itemize thành đoạn riêng, không còn ▶ đi kèm.
     Áp cùng quy tắc cho dòng ⇒ ở slide TCM (trước đó cũng ▶ + ⇒).
  2. Trang 10 (bảng đối sánh, cuối slide): "cho mấy dấu chấm xuống dòng /
     bỏ dấu suy ra" → bỏ ⇒, thay bằng 3 dòng • riêng biệt, mỗi ý một
     dòng: scalar cao nhất / dual-beat / PACBTI duy nhất.
  3. Trang 12 (pipeline): "Chữ bị ăn mất xuống dưới" → đúng là bullet
     cuối bị tràn khung (ảnh 0.78 quá cao + caption 2 dòng). Sửa: ảnh
     xuống 0.55 + caption rút 1 dòng. Đã render-check: đủ bullet.
  4. Trang 15 (MPU/bus, cột trái): "Ảnh minh họa hơi bé, cấu hình lại"
     → tách slide thành 2: slide MPU riêng (ảnh lên trên, rộng 0.62,
     sơ đồ vẽ lại chữ to) + slide bus riêng (5 bullet). Lần vẽ lại đầu
     chữ to làm tràn hộp (tiêu đề MPU và nhãn AXI/AHB đè viền) — đã sửa
     bằng cách rút tiêu đề thành "MPU (PMSAv8)", nhãn bus về cỡ 40 và
     đặt đúng khe trống, render-check sạch rồi mới chốt.
- Ảnh 3 (EVS milestones) CHỌN cho Tiến hóa, thành slide mới sau slide
  Tiến hóa: ảnh trái + 5 bullet mốc (M0+/M3, M4, M23/M33, M7, M55) +
  dòng ⇒ "Future Cortex-M là chỗ M85 lấp vào". Trung thực về nguồn:
  biểu đồ ra đời trước M85 nên không có tên M85; chú thích ghi rõ điều
  này. M35P trên hình (M33 + chống giả mạo, biến thể chuyên biệt)
  không đưa vào bullet vì không nằm trong chương — người thuyết trình
  có thể bỏ qua. Ảnh 2 (thang kích thước–hiệu năng) KHÔNG dùng: thứ tự
  của nó là kích thước–hiệu năng chứ không phải thời gian (M7 nằm trên
  M55 dù M55 mới hơn) — chèn vào slide Tiến hóa sẽ gây hiểu nhầm mốc
  thời gian; nếu người dùng vẫn thích thì đổi trong 5 phút.
- Ảnh 1 (so sánh M/R/A) chưa chèn vì tin nhắn chỉ hỏi ảnh 2 hoặc 3 cho
  Tiến hóa; ảnh này hợp với slide profile (slide 7) nếu muốn thêm sau.
- Hệ quả của việc up đè PDF v5: 12 comment cũ không còn hiện trong
  danh sách comment của Drive (anchor cũ mất hiệu lực sau khi thay
  nội dung file) — nhưng nội dung và cách sửa của chúng vẫn đủ trong
  log.md này và đã nằm trong bản v5. 4 comment mới cũng để unresolved
  chờ người dùng kiểm tra.
- Lỗi bảng chạm header TÁI PHÁT ở v6: thêm dòng kết luận thứ 3 làm
  slide cao thêm nên -1cm không còn đủ (đã thử -1cm với kết luận 2 dòng
  thì sạch). Sửa: -1.5cm + arraystretch 1.1→1.0 + siết gap caption.
  Render-check cuối: bảng nằm dưới thanh xanh, 3 dòng • hiện đủ.
- Render-check v6 cuối: xem trực tiếp các trang 9, 10, 11, 13, 15, 16,
  17 — không trang nào bị cắt chữ hay chồng header.

## 2026-11-01 — Bản v7 (23 slide: +1 ảnh chồng ISA, gộp lại MPU+bus)
- Slide Tiến hóa (2.2): chèn ảnh chồng tính năng theo phiên bản ISA
  do người dùng cung cấp (Armv6-M nền tảng → v7 +DSP/FP → v8
  +Stack Limit/TrustZone → v8.1 +PMU/ECC & RAS/PACBTI/Helium) sang
  cột trái, giới hạn chiều cao 3,9cm để không tràn khung; bullet phải
  viết lại để soi đúng từng tầng của ảnh (kèm tên chip mỗi phiên bản:
  v6 M0/M0+, v7 M3/M4/M7, v8 M23/M33, v8.1 M55/M85) + dòng ⇒ tách khỏi
  itemize theo đúng quy tắc "có ⇒ thì bỏ tam giác xanh". Slide mốc
  EVS (theo chip) giữ nguyên — hai slide bổ sung nhau theo 2 trục
  khác nhau (ISA vs chip), không trùng.
- Slide 3.2 GỘP LẠI theo ý người dùng: MPU + bus về một slide, ảnh
  trái + chữ phải (bố cục v5 nhưng dùng sơ đồ đã vẽ lại chữ to ở v6
  nên đọc được). Dòng ⇒ của slide MPU tách ra trước đó được bỏ để
  vừa 6 bullet trong một slide; render-check đủ chữ, không tràn.
- Render-check v7 cuối: xem trực tiếp trang 8 (chồng ISA) và 16
  (MPU+bus gộp) — không cắt chữ, không chồng header.

## 2026-11-02 — Bản v8 (22 slide: bỏ slide bảng đối sánh, theo báo cáo mới)
- Báo cáo Thẻ 2 đã bỏ §2.3 + Bảng 2.1 (2026-11-01) nên slide phải khít
  theo: XÓA slide bảng đối sánh (cả bảng, ô đỏ và 3 dòng kết luận).
  §2 của slide giờ chỉ còn: profile (2.1), tiến hóa + chồng ISA,
  mốc EVS, Edge AI (2.2) — không còn slide so sánh nào, để Chương IV
  nói phần đánh giá.
- Slide scatter Edge AI: dòng ⇒ "M85 cao nhất cả hai trục" (một kết
  luận đánh giá) đổi thành cầu nối động lực: "Edge AI cần cả hai
  trục: scalar cho truyền thống, vector cho ML — §3 đi vào Helium".
  Ảnh scatter giữ nguyên (minh họa động lực, không còn kết luận).
- Sự cố biên dịch: lần build đầu báo lỗi font tcss1095 vì mktexpk
  không nằm trên PATH của phiên làm việc mới (TinyTeX vẫn đủ file,
  chỉ thiếu PATH). Sửa: export PATH="$HOME/.TinyTeX/bin/x86_64-linux"
  trước khi chạy pdflatex — bài học: phiên mới phải export PATH này
  trước mọi lần build Beamer.
- Render-check v8: trang 10 (scatter, dòng ⇒ mới) sạch, đủ chữ.

## 2026-11-02 — Sửa theo 4 comment mới của người dùng trên PDF trong SLIDE_DUY (không đổi số slide, vẫn 22)
- Nguồn: 4 comment của người dùng trên file Chuong-II-Cortex-M85-slide-thuyet-trinh.pdf
  trong SLIDE_DUY, ngày 2026-11-02 (11:34, 11:43, 11:52, 13:13). Đã đối chiếu từng
  comment với đúng vùng chữ anchor trỏ tới trên PDF trước khi sửa, không đoán
  theo tên slide. Các comment vẫn để unresolved trên Drive chờ người dùng kiểm
  tra bản mới rồi quyết.
- Slide 5 RISC/CISC: bỏ dòng lưu ý "RISC ≠ tất định tự động — còn cần in-order,
  TCM, NVIC" (nói trước khái niệm chưa giới thiệu ở slide 5), thay bằng giải
  thích Thumb-2: một tập lệnh duy nhất trộn 16-bit/32-bit, 16-bit cho thao tác
  thường gặp để mã gọn và tiết kiệm Flash, 32-bit cho thao tác phức tạp cần
  nhiều toán hạng hoặc hằng số lớn. Ý "RISC không tự động bằng tất định" dời
  vào kịch bản ở slide 12 (pipeline in-order), không mất.
- Slide 7 Ba profile: dòng mô tả profile M đổi từ "NVIC trễ thấp, RTOS" thành
  "tích hợp nhân, nhớ, ngoại vi trong một chip; chạy bare-metal/RTOS" (NVIC là
  đặc điểm, không phải định nghĩa; NVIC đã có slide 20 riêng).
- Slide 10 Edge AI: chỉ bỏ cụm cuối "— §3 đi vào Helium", giữ nguyên câu kết
  "Edge AI cần cả hai trục: scalar cho truyền thống, vector cho ML" thành kết
  luận của §2, không còn trỏ trước sang §3.
- Slide 11 Sơ đồ khối nhân: dòng bus đổi từ "nhớ ngoài, DMA, ngoại vi" thành
  "nối nhân với hệ thống ngoài nhân — bộ nhớ hệ thống, DMA, ngoại vi" (làm rõ
  "ngoài nhân" chứ không phải chỉ ngoài chip; DMA là chủ thể dùng bus, không
  phải vùng nhớ đích).
- Kịch bản thuyết trình (kich-ban-thuyet-trinh-chuong-II.md) cập nhật khớp cả
  4 sửa trên, kèm câu trả lời nếu thầy hỏi "bộ nhớ hệ thống là gì" ở slide 11.
- Biên dịch: dùng TinyTeX (export PATH="$HOME/.TinyTeX/bin/x86_64-linux" như
  bài học ở v8) — pdflatex hệ thống thiếu font T5 tiếng Việt nên lần build
  đầu bằng nó làm mất dấu, đã bỏ bản đó và build lại bằng TinyTeX, 2 lần,
  exit 0, 22 trang. Render-check trực tiếp 4 trang sửa (5, 7, 10, 11): đủ chữ,
  không tràn khung, không cắt ở đáy trang. Các cảnh báo overfull vbox cũ
  (4–10,8pt) vẫn còn trong log nhưng đã xem trực tiếp các trang tương ứng
  và không cắt nội dung.
- Chưa đẩy lên Drive: bản PDF/tex mới hiện chỉ ở ~/workspace/ch2-slides/
  (main.tex, main.pdf, kịch bản, log này). File trong SLIDE_DUY vẫn là bản
  trước 4 sửa này, chờ người dùng duyệt rồi mới up đè.

## 2026-11-02 — Gộp bản sửa + đổi tiêu đề slide 10 + up lên Drive SLIDE_DUY
- Đổi tên ở SLIDE, không phải ở báo cáo: tiêu đề slide 10 đổi từ
  "2.2. Vì sao Edge AI cần vector?" thành "2.2. Bài toán Edge AI".
  Slide 8 ("Tiến hóa dòng Cortex-M") và slide 9 ("Mốc tiến hóa") giữ
  nguyên, vì đó là phần dẫn vào, còn slide 10 mới là slide về bài toán
  Edge AI. Kịch bản slide 10 đổi tiêu đề theo, nội dung nói giữ nguyên.
- Báo cáo Tab CHƯƠNG II: tiêu đề mục 2.2 đã đổi nhầm ở lượt trước
  ("Bài toán Edge AI") nay đã HOÀN TÁC về đúng tiêu đề gốc "2.2. Sự
  tiến hóa của dòng Cortex-M và bài toán Edge AI hiện đại", kiểm tra
  lại bằng Docs API, vẫn Heading 3, các tab khác không động tới.
- Bản gộp cuối (22 slide, TinyTeX 2 lần, exit 0) chứa đủ cả 5 sửa:
  slide 5 Thumb-2, slide 7 profile M, slide 10 bỏ "§3 đi vào Helium",
  slide 11 bus "hệ thống ngoài nhân", và slide 10 đổi tiêu đề thành
  "Bài toán Edge AI". Đã kiểm tra bằng trích xuất văn bản PDF (các cụm
  mới có mặt, các cụm cũ đã mất) và render-check trực tiếp slide 10:
  tiêu đề mới nằm gọn trong thanh xanh.
- Up lên Drive SLIDE_DUY (1ApXDeGCFs8t7sCyeIuMLT0jMyL25DcGe), up đè đúng
  2 file cũ, không tạo file mới:
  - Chuong-II-Cortex-M85-slide-thuyet-trinh.pdf (id 1wMJb6WFkPmc6qGxZcWBvsUO5ecUcTZvS)
  - ch2-slides.zip (id 1nTOSN0GKMWFrmGhJezr75RB_nooZG6_F, cùng cấu trúc
    cũ: main.tex, figs/, README.txt, log.md, main.pdf)
- Lưu ý về comment (theo đúng bài học ở v6): up đè PDF sẽ làm 4 comment
  mới ngày 2026-11-02 mất anchor và không còn hiện trong danh sách
  comment của Drive, nhưng nội dung và cách sửa của chúng đã ghi đủ
  trong log.md này, nên không mất thông tin.

## 2026-11-02 — Bỏ chữ "Nguồn:" và trích dẫn [x] khỏi chú thích (chỉ Chương II + slide Chương II)
- Phạm vi do người dùng chốt: chỉ Tab CHƯƠNG II trong báo cáo và slide
  Chương II, không động tới các chương khác hay Thẻ 1.
- Quy tắc áp dụng, theo đúng ví dụ người dùng đưa (slide 7): bỏ nhãn
  "Nguồn:" và các trích dẫn dạng [12], [8], [16], [6], [15] trong chú
  thích; giữ lại câu mô tả nội dung và tên tài liệu lồng trong câu
  (Arm, Guide, EEFocus, Embedded Vision Summit) để hình không bị mất
  gốc, chứ không xóa tên tài liệu hoàn toàn.
- Báo cáo Tab 2, đã kiểm tra lại bằng Docs API: Hình 2.1 bỏ [16];
  Hình 2.3 bỏ câu "Nguồn: sơ đồ khối Cortex-M85 do Arm công bố.";
  Hình 2.4 bỏ câu "Nguồn: ARM, Guide 107950, Figure 2-2 [12].";
  Hình 2.5 bỏ [12]; Hình 2.6 bỏ câu "Nguồn: ARM, White paper
  107564, Figure 2-1 [8]."; Hình 2.7 bỏ [6], [15]. Hình 2.2 và Bảng 2.1
  vốn đã không có nguồn nên giữ nguyên. Nội dung đoạn văn và tài liệu
  tham khảo không đổi.
- Slide, đã biên dịch lại bằng TinyTeX (2 lần, exit 0, 22 trang) và
  render-check slide 7: slide 7 thành "Biểu đồ của Arm; ngôi sao và
  nhãn M85 do nhóm tác giả bổ sung, dẫn lại qua EEFocus."; slide 9,
  10, 12, 16 đổi "Nguồn: X" thành "theo X"; slide 14 bỏ [12]. Các chú
  thích khác vốn không có nguồn nên giữ nguyên.
- Bản slide mới này CHƯA lên Drive, chờ người dùng duyệt rồi mới up đè
  (up đè sẽ lại làm mất anchor comment cũ trên Drive, như đã ghi ở trên).

## 2026-11-02 — Rút gọn hẳn chú thích: chỉ Nhãn + số + nội dung ngắn, chữ nhỏ nghiêng dưới ảnh (chỉ Chương II)
- Người dùng chốt lần cuối: chú thích ảnh và bảng chỉ còn nhãn + số +
  nội dung ngắn, hết, không nguồn, không chữ "theo", không câu thêm.
  Lần sửa trước (giữ tên tài liệu lồng trong câu, đổi "Nguồn:" thành
  "theo") là chưa đúng ý, nay sửa lại hẳn theo dạng này.
- Báo cáo Tab 2, đã kiểm tra lại bằng Docs API, tất cả đều in nghiêng
  10pt (nhỏ hơn chữ chính 11pt), nằm ngay dưới ảnh trong cùng đoạn:
  Hình 2.1: Ba profile Cortex-A, Cortex-R, Cortex-M; Hình 2.2: Chồng
  tính năng theo phiên bản ISA từ Armv6-M tới Armv8.1-M; Hình 2.3: Sơ
  đồ khối nhân Cortex-M85; Hình 2.4: Cấu trúc pipeline M85; Hình 2.5:
  Sơ đồ cầu nối TCM của Cortex-M85; Hình 2.6: Thực thi theo beat của
  Helium; Hình 2.7: TrustZone cho Armv8-M; Bảng 2.1: Đối chiếu đặc điểm
  Cortex-M85 với phần hiện thực trên RA8M1 (Chương III). Trong lúc sửa
  đã phát hiện và sửa ngay 2 chú thích bị thừa chữ H đầu (Hình 2.5 và
  2.7) do cấu trúc đoạn của 2 hình đó khác các hình còn lại.
  Lưu ý: các chi tiết bị rút khỏi chú thích (ngôi sao do nhóm bổ sung
  ở Hình 2.1, khối nét đứt ở Hình 2.3, danh sách đơn vị ở Hình 2.4,
  dung lượng IP tối đa ở Hình 2.5, SG/BXNS/SAU ở Hình 2.7) vẫn còn
  trong đoạn văn ngay quanh hình, trừ ghi chú ngôi sao ở Hình 2.1 là
  trước đây chỉ có trong chú thích — nếu cần giữ ghi chú đó thì phải
  chuyển nó vào đoạn văn, không để lại trong chú thích.
- Slide, đã biên dịch lại bằng TinyTeX (2 lần, exit 0, 22 trang), trong
  toàn bộ PDF không còn chữ "Nguồn:" nào, và render-check các slide
  7, 11, 14: chú thích là chữ nhỏ nghiêng nằm dưới ảnh, đúng dạng ngắn
  trên. 16 chú thích hình trong slide đều đã rút về nội dung ngắn,
  ví dụ slide 7 chỉ còn "Ba profile Cortex-A, Cortex-R, Cortex-M",
  slide 11 chỉ còn "Sơ đồ khối nhân Cortex-M85", slide 14 chỉ còn
  "Sơ đồ cầu nối TCM".
- Bản này ĐÃ lên Drive lúc 14:56 ngày 2026-11-02 (PDF + zip, hash tải
  về trùng local, trong PDF không còn chữ "Nguồn:" nào). Lý do up lúc
  này: hai đợt sửa chú thích trước đó chỉ để ở máy này chờ duyệt nên
  file trên Drive vẫn là bản cũ còn "Nguồn:", người dùng đã mở đúng
  bản cũ đó và phản ánh — từ nay sửa chú thích xong là up luôn, không
  giữ lại chờ duyệt nữa khi người dùng đã chốt dạng chú thích.

## 2026-11-02 — Căn lại bảng CISC/RISC slide 5
- Lỗi: đường kẻ trên của bảng nằm lấn vào mép dưới thanh tiêu đề
  xanh, bảng lệch phải so với giữa trang (tâm bảng lệch khoảng 28pt
  so với tâm trang).
- Sửa: thêm khoảng trống 0,45 cm trước bảng, bỏ tùy chọn [t] của
  tabular, đặt bảng trong môi trường center. Kiểm tra bằng tọa độ
  trong PDF: đường kẻ trên ở y = 85,5pt (thanh xanh cao ~33pt, tức
  cách thanh một khoảng trắng rõ rệt), bảng từ x = 33,2 đến 420,3pt,
  tâm bảng trùng đúng tâm trang 226,8pt. Render-check slide 5 sạch.
- Bản này ĐÃ lên Drive lúc 15:03 ngày 2026-11-02 (PDF + zip, hash
  tải về trùng local), không để ở máy này nữa.
