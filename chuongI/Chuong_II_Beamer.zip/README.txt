SLIDE THUYET TRINH - CHUONG II: ARM CORTEX-M85
================================================
Chuyen tu The 2 (Tab 2) cua Google Doc "Bao cao - He thong nhung dung
ARM Cortex-M85 (Case study Renesas RA8M1)" sang 23 slide Beamer.
Template: anh nen figs/bg.jpg lay tu folder Drive SLIDE_DUY (thanh xanh
+ logo PTIT, ty le 16:9). Tieu de nam trong thanh xanh; cac slide co hinh
dat anh ben trai, noi dung ben phai; moi slide chi lay y chinh (KISS,
6x6); noi dung tran thi tach slide thay vi nhet chung.

BIEN DICH
- Cach 1 (may cuc bo, can goi beamer + vntex): pdflatex main.tex (2 lan)
- Cach 2 (Overleaf): upload toan bo thu muc nay, chon Compiler = pdfLaTeX,
  bien dich 2 lan de on dinh so trang.
- Yeu cau: goi beamer, babel-vietnamese (T5), tikz, booktabs.

FILE
- main.tex : toan bo slide (23 trang)
- figs/bg.jpg : anh nen template
- figs/fig21_profiles.png ... fig26_trustzone.png : cac hinh cua Chuong II
  (2.1 profile co ngoi sao M85, 2.2 khoi nhan, 2.3 pipeline, 2.4 cau noi TCM
  do nhom tac gia ve, 2.5 beats Helium, 2.6 TrustZone)
- figs/fig_vn_harvard.png, figs/fig_mcu_mpu.png : hinh minh hoa them cho muc 1.1, 1.2
- main.pdf : ban PDF bien dich thu (kem theo trong zip)

LUU Y
- Chu thich nguon nam ngay duoi moi hinh trong slide.
- Hinh 2.4 (cau noi TCM) la so do do nhom tac gia ve minh hoa, khong phai
  hinh goc cua Arm; dung luong trong hinh la muc toi da cua IP.
- Slide 21-22 tach Bang 2.2 thanh 2 phan de khong chen chuc.

---
Ban v5 (2026-11-01): 22 slide. Sua theo 12 comment tren PDF v4 + 2 anh moi (scatter ML vao slide 9, pipeline don gian vao slide 13, so do MPU ve moi vao slide 15, so do tong quat he thong vao slide 20). Bang doi sanh gop voi slide diem nhan + khoanh o do. Chi tiet xem log.md.
Ban v7 (2026-11-01): 23 slide. Them anh chong ISA vao slide Tien hoa; gop lai MPU+bus (anh trai, chu phai) theo y user. Chi tiet xem log.md.
